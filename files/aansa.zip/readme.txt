﻿The font file in this archive was created by Andrew Tyler atyler.dev@gmail.com
License: http://creativecommons.org/licenses/by-sa/3.0/us/
LEGAL NOTICE:
In using this font you must comply with the licensing terms described in the 
file “license.txt” included with this archive.
If you redistribute the font file in this archive, it must be accompanied by 
all the other files from this archive, including this one.

*****
Best used at 12pt size
